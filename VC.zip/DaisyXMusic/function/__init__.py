from DaisyXMusic.function.admins import admins, get, set

__all__ = ["set", "get", "admins"]
