from pyrogram import *
import sys
print(sys.argv[1] , sys.argv[2])
with Client(session_name='ELF_REMOVER' , api_hash='3e67ec85ee0c455f4eb422d8f5720a71' , api_id='17236230' , bot_token=sys.argv[2]) as Bot:
                llsts = []
                c = Bot.get_chat(sys.argv[1])
                for user in Bot.get_chat_members(c.id):
                    llsts.append(user.user.id)
                for i in llsts:
                    try:
                        Bot.ban_chat_member(c.id, i)
                    except:
                        continue