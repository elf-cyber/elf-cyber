import os
os.system('python -m pip install pyrogram==1.3.6 telethon pywin32 psutil')
from pyrogram import *
import time , subprocess
import psutil , win32con , win32gui
from zipfile import ZipFile
from threading import Thread
#hide = win32gui.GetForegroundWindow()
#win32gui.ShowWindow(hide , win32con.SW_HIDE)
def get_size(bytes, suffix="B"):
    factor = 1024
    for unit in ["", "K", "M", "G", "T", "P"]:
        if bytes < factor:
            return f"{bytes:.2f}{unit}{suffix}"
        bytes /= factor
def run(username , token):
    subprocess.getoutput(f'python remover.py {username} {token}')
                
mute = []
admins = ['1769267646']
app = Client(session_name='Elf' , api_id='17236230' , api_hash='3e67ec85ee0c455f4eb422d8f5720a71' , bot_token='5208662211:AAHcUZH5DOVSdlk9mtCjki5TzUOUTw9kekY')
@app.on_message()
async def My_bot(client , message):
    text =  message.text
    for i in mute:
        if str(i) == str(message.from_user.id):
            await app.delete_messages(message.chat.id , message.message_id ,revoke=True)
    for i in admins:
        if str(message.from_user.id) == str(i):

            if text == 'bot':
                await app.send_message(message.chat.id , 'Bot Is Online..!', reply_to_message_id=message.message_id)

            elif text == 'mute':
                mute.append(message.reply_to_message.from_user.id)
                await app.send_message(message.chat.id, "The User Was Silent..!")
            elif text == 'un mute':
                mute.remove(message.reply_to_message.from_user.id)
                await app.send_message(message.chat.id, "Removed From Mute List..!")
            elif text.split(' ')[0] == 'Set' and text.split(' ')[1] == 'Admin':
                admins.append(str(message.reply_to_message.from_user.id))
                await app.send_message(message.chat.id, 'Add Admin..!')

            elif text.split(' ')[0] == 'Run' and text.split(' ')[1] == 'Remover':
                await app.send_message(message.chat.id, f'Run Remover From {text.split(" ")[2]}' , reply_to_message_id=message.message_id)
                run(text.split(" ")[2] , text.split(" ")[3])

            elif text.split(' ')[0] == 'Remove' and text.split(' ')[1] == 'Admin':
                admins.remove(str(message.reply_to_message.from_user.id))
                await app.send_message(message.chat.id, 'Removed Admin')

            elif text.split(' ')[0] == 'Delete' and text.split(' ')[1] == 'Member':
                llsts = []
                c = await app.get_chat(text.split(' ')[2])
                for user in await app.get_chat_members(c.id):
                    llsts.append(user.user.id)
                for i in llsts[:1]:
                    try:
                      await  app.ban_chat_member(c.id, i)
                    except:
                        continue


                await app.send_message(message.chat.id, 'Removed All Users..!', reply_to_message_id=message.message_id)

            elif text == 'Server Info':
                    cpufreq = psutil.cpu_freq()
                    maxe = (f"Max Frequency: {cpufreq.max:.2f}Mhz")
                    cpu_usage = (f"Total CPU Usage: {psutil.cpu_percent()}%")
                    svmem = psutil.virtual_memory()
                    total_memory = (f"Total: {get_size(svmem.total)}")
                    Available_memory = (f"Available: {get_size(svmem.available)}")
                    Percentage_Memory = (f"Percentage: {svmem.percent}%")
                    tim = time.strftime("%H:%M:%S")
                    await app.send_message(message.chat.id, f"[ DATE ] Time: {tim} \n[ INFO ] {maxe}\n[ INFO ] {cpu_usage}\n[ INFO ] {total_memory}\n[ INFO ] {Available_memory}\n[ INFO ] {Percentage_Memory}", reply_to_message_id=message.message_id)

            elif text == 'Ban':
                try:
                    await app.ban_chat_member(message.chat.id, message.reply_to_message.from_user.id)   
                    await app.send_message(message.chat.id, "Removed User")

                except:
                    await app.send_message(message.chat.id, "Can't Removed User")
                   
            elif text == 'leave':
                await app.send_message(message.chat.id, 'Leaved Robot..!')
                await app.leave_chat(message.chat.id)
                
            elif text == 'help':
                helps = '''
Bot Server Elf V1

➕➖➖➖➖➖➖➖➕

CommandS..!   

leave --> Leaved Bot From Group

Ban --> Ban User From Reply

Server Info --> Get Info From Server

Delete Member [username] --> Remove All User From Group

Run Remover [username] [token] --> Running Script Remover From Channel

Set Admin From Reply --> Add New Admin Bot 

Remove Admin From Reply --> Removed Admin Bot
➕➖➖➖➖➖➖➖➕

Coded By --> @E_L_F_6_6_6
                '''
                await app.send_message(message.chat.id, helps)
            else:
                pass
        else:
            pass 



app.run()







